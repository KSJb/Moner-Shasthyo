### My Slider jQuery Plugin  
  
___My-Slider___ é um ___plugin___ _jQuery_ criado para facilitar a criação de ___slides___ — que particulamente considero um pouco complicado, e imagino que **outras pessoas também** —.  
Após horas de trabalho, cheguei ao resultado... Uffa. :sweat_smile:  
      
            
**Importante:**  
**Recomendo seriamente a leitura da Documentação API:**  
[**Clique aqui**](https://github.com/lffg/slider-plugin/wiki/Documenta%C3%A7%C3%A3o-API).

---

Espero que gostem! <3  
      
Feito por:  
**Luiz Felipe G.** @lffg  
      
Agradecimentos:  
Kyo Panda. @arturhns  
      
      
**Importante:**  
**Todo** o código deste plugin está sob a [**Licença MIT**](https://github.com/lffg/slider-plugin/blob/master/LICENSE).  
Copyright (c) Luiz Felipe G. 2017.
